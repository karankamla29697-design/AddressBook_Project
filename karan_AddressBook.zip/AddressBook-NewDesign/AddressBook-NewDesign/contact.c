#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"

int isValidPhone(AddressBook *addressBook, char phone[]);
int isValidEmail(AddressBook *addressBook, char email[]);

void initialize(AddressBook *addressBook)
{
    addressBook->contactCount = 0;
    loadContactsFromFile(addressBook);
}

void listContacts(AddressBook *addressBook, int sortCriteria)
{
    printf("\nTotal contacts: %d\n", addressBook->contactCount);

    for(int i = 0; i < addressBook->contactCount; i++)
    {
        printf("%s\t%s\t%s\n",
               addressBook->contacts[i].name,
               addressBook->contacts[i].phone,
               addressBook->contacts[i].email);
    }
}
void editContact(AddressBook *addressBook)
{
    char name[50];
    int index[100], count = 0;

    printf("Enter name to edit: ");
    scanf(" %[^\n]", name);

    // find all matching contacts
    for(int i = 0; i < addressBook->contactCount; i++)
    {
        if(strcmp(name, addressBook->contacts[i].name) == 0)
        {
            printf("%d. %s\t%s\t%s\n", count+1,
                   addressBook->contacts[i].name,
                   addressBook->contacts[i].phone,
                   addressBook->contacts[i].email);

            index[count++] = i;
        }
    }

    if(count == 0)
    {
        printf("Contact not found!\n");
        return;
    }

    int choice = 1;

    if(count > 1)
    {
        printf("Choose contact to edit (1-%d): ", count);
        scanf("%d", &choice);

        if(choice < 1 || choice > count)
        {
            printf("Invalid choice!\n");
            return;
        }
    }

    int editIndex = index[choice - 1];

    printf("Enter new Name: ");
    scanf(" %[^\n]", addressBook->contacts[editIndex].name);

    // phone validation
    do
    {
        printf("Enter new Phone: ");
        scanf("%s", addressBook->contacts[editIndex].phone);

        if(!isValidPhone(addressBook, addressBook->contacts[editIndex].phone))
            printf("Invalid phone!\n");

    } while(!isValidPhone(addressBook, addressBook->contacts[editIndex].phone));

    // email validation
    do
    {
        printf("Enter new Email: ");
        scanf("%s", addressBook->contacts[editIndex].email);

        if(!isValidEmail(addressBook, addressBook->contacts[editIndex].email))
            printf("Invalid email!\n");

    } while(!isValidEmail(addressBook, addressBook->contacts[editIndex].email));

    printf("Contact updated successfully!\n");
}
// phone validation
int isValidPhone(AddressBook *addressBook, char phone[])
{
    int i = 0;

    while(phone[i] != '\0')
    {
        if(phone[i] < '0' || phone[i] > '9')
            return 0;
        i++;
    }

    if(i != 10)
        return 0;

    for(int j = 0; j < addressBook->contactCount; j++)
    {
        if(strcmp(phone, addressBook->contacts[j].phone) == 0)
            return 0;
    }

    return 1;
}

// email validation
int isValidEmail(AddressBook *addressBook, char email[])
{
    int at = 0, dot = 0;

    for(int i = 0; email[i]; i++)
    {
        if(email[i] == '@') at++;
        if(email[i] == '.') dot++;
    }

    if(at != 1 || dot != 1)
        return 0;

    for(int i = 0; i < addressBook->contactCount; i++)
    {
        if(strcmp(email, addressBook->contacts[i].email) == 0)
            return 0;
    }

    return 1;
}

void createContact(AddressBook *addressBook)
{
    printf("Enter Name: ");
    scanf(" %[^\n]", addressBook->contacts[addressBook->contactCount].name);

    do
    {
        printf("Enter Phone: ");
        scanf("%s", addressBook->contacts[addressBook->contactCount].phone);

        if(!isValidPhone(addressBook, addressBook->contacts[addressBook->contactCount].phone))
            printf("Invalid phone!\n");

    } while(!isValidPhone(addressBook, addressBook->contacts[addressBook->contactCount].phone));

    do
    {
        printf("Enter Email: ");
        scanf("%s", addressBook->contacts[addressBook->contactCount].email);

        if(!isValidEmail(addressBook, addressBook->contacts[addressBook->contactCount].email))
            printf("Invalid email!\n");

    } while(!isValidEmail(addressBook, addressBook->contacts[addressBook->contactCount].email));

    addressBook->contactCount++;

    printf("Contact added!\n");
}

void searchContact(AddressBook *addressBook)
{
    char name[50];
    int found = 0;

    printf("Enter name to search: ");
    scanf(" %[^\n]", name);

    for(int i = 0; i < addressBook->contactCount; i++)
    {
        if(strcmp(name, addressBook->contacts[i].name) == 0)
        {
            printf("%s\t%s\t%s\n",
                   addressBook->contacts[i].name,
                   addressBook->contacts[i].phone,
                   addressBook->contacts[i].email);
            found = 1;
        }
    }

    if(!found)
        printf("Not found\n");
}

void deleteContact(AddressBook *addressBook)
{
    char name[50];
    int index[100], count = 0;

    printf("Enter name to delete: ");
    scanf(" %[^\n]", name);

    for(int i = 0; i < addressBook->contactCount; i++)
    {
        if(strcmp(name, addressBook->contacts[i].name) == 0)
        {
            printf("%d. %s\t%s\t%s\n", count+1,
                   addressBook->contacts[i].name,
                   addressBook->contacts[i].phone,
                   addressBook->contacts[i].email);

            index[count++] = i;
        }
    }

    if(count == 0)
    {
        printf("Not found\n");
        return;
    }

    int choice = 1;

    if(count > 1)
    {
        printf("Choose contact (0-%d): ", count);
        scanf("%d", &choice);
    }

    int del = index[choice-1];

    for(int i = del; i < addressBook->contactCount-1; i++)
    {
        addressBook->contacts[i] = addressBook->contacts[i+1];
    }

    addressBook->contactCount--;

    printf("Deleted successfully\n");
}

void saveAndExit(AddressBook *addressBook)
{
    saveContactsToFile(addressBook);
    exit(0);
}
#include <stdio.h>
#include "file.h"

void loadContactsFromFile(AddressBook *addressBook)
{
    FILE *fptr = fopen("contact.csv", "r");

    if(fptr == NULL)
    {
        printf("No file found. Starting fresh.\n");
        return;
    }

    addressBook->contactCount = 0;

    while(fscanf(fptr, " %[^,],%[^,],%[^\n]\n",
                 addressBook->contacts[addressBook->contactCount].name,
                 addressBook->contacts[addressBook->contactCount].phone,
                 addressBook->contacts[addressBook->contactCount].email) != EOF)
    {
        addressBook->contactCount++;
    }

    fclose(fptr);
}

void saveContactsToFile(AddressBook *addressBook)
{
    FILE *fptr = fopen("contact.csv", "w");

    if(fptr == NULL)
    {
        printf("Error saving file!\n");
        return;
    }

    for(int i = 0; i < addressBook->contactCount; i++)
    {
        fprintf(fptr, "%s,%s,%s\n",
                addressBook->contacts[i].name,
                addressBook->contacts[i].phone,
                addressBook->contacts[i].email);
    }

    fclose(fptr);
}
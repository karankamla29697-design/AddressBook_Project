#include <stdio.h>
#include "contact.h"
#include "file.h"

int main() 
{
    int choice, sortChoice = 0;
    AddressBook addressBook;

    initialize(&addressBook);

    while(1)
    {
        printf("\n====== Address Book Menu ======\n");
        printf("1. Create contact\n");
        printf("2. Search contact\n");
        printf("3. Edit contact\n");
        printf("4. Delete contact\n");
        printf("5. List all contacts\n");
        printf("6. Save contacts\n");		
        printf("7. Exit\n");
        printf("Enter your choice: ");

        if(scanf("%d", &choice) != 1)
        {
            printf("Invalid input!\n");
            while(getchar() != '\n'); // clear buffer
            continue;
        }

        switch(choice) 
        {
            case 1:
                createContact(&addressBook);
                break;

            case 2:
                searchContact(&addressBook);
                break;

            case 3:
                editContact(&addressBook);
                break;

            case 4:
                deleteContact(&addressBook);
                break;

            case 5:
                listContacts(&addressBook, sortChoice);
                break;

            case 6:
                saveContactsToFile(&addressBook);
                printf("Contacts saved successfully!\n");
                break;

            case 7:
                printf("Saving and exiting...\n");
                saveContactsToFile(&addressBook);
                return 0;

            default:
                printf("Invalid choice! Try again.\n");
        }
    }
}